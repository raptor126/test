import discord
from discord.ext import commands
from discord import app_commands
from .utils import EMOJI_ON, EMOJI_OFF

def status_line(name: str, enabled: bool) -> str:
    return f"{EMOJI_ON if enabled else EMOJI_OFF} **{name}**"

def make_embed(bot: commands.Bot) -> discord.Embed:
    e = discord.Embed(title="Panneau de configuration", description="Activez / désactivez les modules du bot.", color=discord.Color.blurple())
    states = getattr(bot, "module_states", {})
    lines = [status_line(name, enabled) for name, enabled in states.items()]
    e.add_field(name="Modules", value="\n".join(lines) if lines else "Aucun module détecté.", inline=False)
    e.set_footer(text="Les états sont stockés en mémoire et seront réinitialisés au redémarrage.")
    return e

class ToggleSelect(discord.ui.Select):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        options = []
        for key, enabled in bot.module_states.items():
            label = f"{'ON' if enabled else 'OFF'} • {key}"
            desc = "Actuellement activé" if enabled else "Actuellement désactivé"
            options.append(discord.SelectOption(label=label, value=key, description=desc, emoji=(EMOJI_ON if enabled else EMOJI_OFF)))
        super().__init__(placeholder="Choisir un module à basculer…", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        key = self.values[0]
        self.bot.module_states[key] = not self.bot.module_states.get(key, True)
        await interaction.response.edit_message(embed=make_embed(self.bot), view=ConfigView(self.bot))

class ConfigView(discord.ui.View):
    def __init__(self, bot: commands.Bot):
        super().__init__(timeout=300)
        self.bot = bot
        self.add_item(ToggleSelect(bot))

    @discord.ui.button(label="Tout activer", style=discord.ButtonStyle.success)
    async def enable_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        for k in self.bot.module_states.keys():
            self.bot.module_states[k] = True
        await interaction.response.edit_message(embed=make_embed(self.bot), view=ConfigView(self.bot))

    @discord.ui.button(label="Tout désactiver", style=discord.ButtonStyle.danger)
    async def disable_all(self, interaction: discord.Interaction, button: discord.ui.Button):
        for k in self.bot.module_states.keys():
            self.bot.module_states[k] = False
        await interaction.response.edit_message(embed=make_embed(self.bot), view=ConfigView(self.bot))

    @discord.ui.button(label="Actualiser", style=discord.ButtonStyle.secondary)
    async def refresh(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.edit_message(embed=make_embed(self.bot), view=ConfigView(self.bot))

class ConfigPanel(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="configuration", description="Ouvre le panneau de configuration des modules")
    @app_commands.default_permissions(administrator=True)
    async def configuration(self, interaction: discord.Interaction):
        # Si de nouveaux cogs ont été chargés après démarrage, s'assurer qu'ils sont présents
        for ext in list(self.bot.cogs.keys()):
            key = ext.lower()
            if key not in self.bot.module_states:
                self.bot.module_states[key] = True
        await interaction.response.send_message(embed=make_embed(self.bot), view=ConfigView(self.bot), ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(ConfigPanel(bot))
