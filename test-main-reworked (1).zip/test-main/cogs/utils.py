from discord import app_commands
import discord

EMOJI_ON = "🟢"
EMOJI_OFF = "🔴"

def module_enabled_check(module_key: str):
    async def predicate(interaction: discord.Interaction) -> bool:
        client = interaction.client
        state = getattr(client, "module_states", {})
        enabled = state.get(module_key, True)
        if not enabled:
            try:
                await interaction.response.send_message(
                    f"Le module **{module_key}** est {EMOJI_OFF} désactivé par la configuration.", 
                    ephemeral=True
                )
            except discord.InteractionResponded:
                await interaction.followup.send(
                    f"Le module **{module_key}** est {EMOJI_OFF} désactivé par la configuration.", 
                    ephemeral=True
                )
            return False
        return True
    return app_commands.check(predicate)
