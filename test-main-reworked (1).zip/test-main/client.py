import discord
from discord.ext import commands
import os
import asyncio

intents = discord.Intents.all()
bot = commands.Bot(command_prefix="!", intents=intents)

DEFAULT_MODULES = [
    "administration","arrivants","banlien","emdeb","giveaways","invite","jeux",
    "message","reaction","role","status","suggestions","tickets","vouch","configpanel"
]
bot.module_states = {name: True for name in DEFAULT_MODULES}

@bot.event
async def setup_hook():
    for filename in os.listdir("./cogs"):
        if filename.endswith(".py") and filename != "__init__.py":
            try:
                await bot.load_extension(f"cogs.{filename[:-3]}")
                print(f"🔹 Cog chargé : {filename}")
            except Exception as e:
                print(f"❌ Erreur de chargement du cog {filename}: {e}")
    try:
        synced = await bot.tree.sync()
        print(f"✅ {len(synced)} commandes slash synchronisées.")
    except Exception as e:
        print(f"❌ Erreur de synchronisation des slash commands : {e}")

@bot.event
async def on_ready():
    print(f"🤖 Connecté en tant que {bot.user} (ID: {bot.user.id})")

async def main():
    async with bot:
        await bot.start("")  # <-- Ajoute ton token ici

if __name__ == "__main__":
    asyncio.run(main())
